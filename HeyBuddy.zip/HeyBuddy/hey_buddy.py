 import speech_recognition as sr
import pyttsx3
import datetime
import wikipedia
import webbrowser
import os
import random

# Initialize speech engine
engine = pyttsx3.init()

def speak(text):
    print(f"Assistant: {text}")
    engine.say(text)
    engine.runAndWait()

def listen():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Listening...")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)

    try:
        command = r.recognize_google(audio)
        print(f"You said: {command}")
        return command.lower()
    except:
        return ""

# Greet user by name
def greet_user():
    if not os.path.exists("username.txt"):
        speak("Hi, what is your name?")
        name = listen()
        if name:
            with open("username.txt", "w") as f:
                f.write(name)
            speak(f"Nice to meet you, {name}!")
    else:
        with open("username.txt", "r") as f:
            name = f.read()
        speak(f"Welcome back, {name}!")

# Add to-do item
def add_to_todo(item):
    with open("todo.txt", "a") as file:
        file.write(f"- {item}\n")
    speak(f"I've added {item} to your to-do list.")

# Jokes list
jokes = [
    "Why don’t scientists trust atoms? Because they make up everything!",
    "Why was the math book sad? It had too many problems.",
    "I told my computer I needed a break, and now it won’t stop sending me KitKat ads."
]

# Respond to commands
def respond(command):
    if "wikipedia" in command:
        speak("Searching Wikipedia...")
        try:
            query = command.replace("wikipedia", "")
            results = wikipedia.summary(query, sentences=2)
            speak(results)
        except:
            speak("Sorry, I couldn't find anything on Wikipedia.")
    
    elif "open youtube" in command:
        webbrowser.open("https://www.youtube.com")
        speak("Opening YouTube.")

    elif "open google" in command:
        webbrowser.open("https://www.google.com")
        speak("Opening Google.")

    elif "time" in command:
        now = datetime.datetime.now().strftime("%I:%M %p")
        speak(f"The time is {now}.")

    elif "tell me a joke" in command or "joke" in command:
        speak(random.choice(jokes))

    elif "add to-do" in command or "to-do" in command:
        speak("What should I add to your to-do list?")
        item = listen()
        if item:
            add_to_todo(item)

    elif "exit" in command or "stop" in command:
        speak("Goodbye!")
        exit()

    else:
        speak("Sorry, I don't know that yet. Try asking something else.")

# MAIN loop with Wake Word
if __name__ == "__main__":
    greet_user()
    speak("Hey Buddy is ready. Say 'Hey Buddy' to start.")

    while True:
        wake = listen()
        if "hey buddy" in wake:
            speak("Yes? I'm listening...")
            command = listen()
            if command:
                respond(command)

